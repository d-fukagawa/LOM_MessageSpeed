# LOM_MessageSpeed

『活俠傳（Legend of Mortal）』の通常会話における文字送り速度を変更する、非公式のBepInExプラグインです。

本プラグインは、ゲームの開発元・販売元、翻訳MOD作者、BepInEx開発者とは無関係です。通常会話の文字送りだけを対象とし、オート待機、入力待機、演出、戦闘、`Time.timeScale`は変更しません。

## 必要環境

- Windows
- Steam版『活俠傳』
- Unity Mono版に対応するBepInEx 6
- 対応確認済みゲームバージョン: `release_1.0.5000.13`
- 対応確認済みUnityバージョン: `2020.3.49f1`
- 対応確認済みBepInExバージョン: `6.0.0-be.692`

ゲームやBepInExの更新後は、内部仕様の変更により動作しなくなる可能性があります。

## インストール

1. ゲームを完全に終了します。
2. Unity Mono版に対応するBepInEx 6を導入します。
3. ZIPを展開し、`LOM_MessageSpeed.dll`を次の場所へ配置します。フォルダーがなければ作成してください。

```text
<GameRoot>/BepInEx/plugins/LOM_MessageSpeed/LOM_MessageSpeed.dll
```

4. ゲームを起動します。

ZIPに含まれるDLL以外を、ゲームの`Managed`ディレクトリへ入れないでください。ゲーム本体のDLLをコピー、改変、置換する必要はありません。

## 設定

初回起動後、次の設定ファイルが生成されます。

```text
<GameRoot>/BepInEx/config/lom-messagespeed.cfg
```

設定例:

```ini
[General]
Enabled = true

[Message]
SpeedMultiplier = 1.5
```

- `Enabled = false`: ゲーム本来の挙動
- `SpeedMultiplier = 1.0`: ゲーム本来の速度
- `SpeedMultiplier = 1.5`: 1.5倍速
- `SpeedMultiplier = 2.0`: 2倍速
- `SpeedMultiplier = 0.5`: 半速
- 設定可能範囲: `0.1`～`10.0`
- 実機確認済み範囲: `0.2`～`10.0`

`0.1`は設定可能ですが、問題なく動作することを確認済みとはしていません。設定変更はゲームを完全に終了してから行い、次回起動時に反映してください。

## アンインストール

1. ゲームを完全に終了します。
2. 配置した`LOM_MessageSpeed.dll`だけを削除します。

設定ファイル`BepInEx/config/lom-messagespeed.cfg`が残っていてもゲームには影響しません。不要であればユーザー自身で削除できます。ゲーム本体ファイルやセーブデータを復元する必要はありません。

## 互換性と既知の制限

- LOM JP Font Patch、LOM JP Ruby Prototype、LOM JP String Vault、XUnity Auto Translatorとは、確認した範囲内で共存します。
- LOM_ReadSkipおよびLOM_DetailedDisplayは設計上の競合評価を行っていますが、今回の実機環境では未確認です。
- `Fungus.Writer.writingSpeed`を変更する別のMODとは競合する可能性があります。
- `character`以外のすべての会話種別、すべての対象外UI、すべてのspeedタグ、VO、wait、スキップ経路を網羅確認したものではありません。
- speedタグ区間ではゲーム側が指定した速度を優先し、speed-reset後に通常倍率へ戻る設計です。
- 句読点待機、明示wait、VO待機、入力待機、オート待機は倍率の対象外です。
- ルビ表示、クリックによる即時表示、次行入力、句読点待機は、確認した範囲内で正常に動作しました。
- `SpeedMultiplier = 0.1`で一度だけロード演出から進まない事象がありました。プラグインの例外や警告は確認されず、再現試験は実施していないため、原因は特定していません。

## 問題報告

[GitHub Issues](https://github.com/d-fukagawa/LOM_MessageSpeed/issues)を第一窓口とします。SNSのDM窓口は後日追記予定であり、現時点では指定していません。

問題を報告する前に本プラグインを外し、同じ問題が再現するか確認してください。報告には、可能な範囲で次の情報を含めてください。

- ゲームバージョン
- BepInExバージョン
- LOM_MessageSpeedバージョン
- `Enabled`と`SpeedMultiplier`の値
- 併用MOD一覧と各バージョン
- 再現手順と再現率
- scene、会話種別、該当文章の特徴
- 期待した結果と実際の結果
- `BepInEx/LogOutput.log`

ログは、ユーザー名、ローカルパス、その他の個人情報が含まれていないか確認してから投稿してください。セーブデータ、ゲームDLL、ゲーム素材は公開Issueへ添付しないでください。将来SNSのDMで受けた再現可能な問題は、個人情報を除いてIssueへ整理することを推奨します。

## 免責事項

本MODは非公式であり、ゲームの開発元・販売元とは無関係です。利用は自己責任でお願いします。動作、完全性、将来の互換性は保証されません。ゲーム、BepInEx、他MODの更新や組み合わせにより動作しなくなる可能性があります。

適用法令で認められる範囲において、作者はデータ損失、進行不能、その他、本MODの利用から生じた損害について責任を負いません。必要に応じてセーブデータをバックアップしてください。問題が発生した場合は、本MODを外して再現性を確認してください。

## ライセンスと第三者製品

本プロジェクト独自のコードおよび文書は[MIT License](LICENSE)で提供されます。ゲーム本体、BepInEx、Harmony、他のMODおよびそれらの素材・コードは本プロジェクトのライセンス対象ではなく、それぞれの権利者に帰属します。配布ZIPにはゲーム本体、BepInEx、Harmony、翻訳データ、ゲーム素材を含みません。
